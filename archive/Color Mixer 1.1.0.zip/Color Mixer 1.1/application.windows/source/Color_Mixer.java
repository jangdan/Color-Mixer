import processing.core.*; 
import processing.xml.*; 

import controlP5.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class Color_Mixer extends PApplet {

/*Color Mixer Application
  by Daniel Min Hyuk Jang
  
  Color Mixer is open source. Use it, mod it, share it.
  Just leave the white text on the right bottom
  
  Version Notes
  
  1.1.0 v 0.7.2
  
  1.1.0 v 0.7.2 (6.10.12)
   - Edited the version (added ControlP5 version) 
   - Lowered the slider for a better look
   
  1.0.0 v 0.7.2 (5.12.12)
   - Released with Naver Blog and Blogger
   
  0.4.rc4 (5.9.12)
   - Open Source license
   - More code commenting
   - Ready to release!!!
   
  0.4.rc3 (5.3.12)
   - Now press Contol(Command)+R to reset
   
  0.4.rc2 (5.3.12)
   - Removed red, green, blue shortcut keys
   - Removed debug code
   
  0.4.rc1 (4.30.12)
   - Reduced file size (a little)
   
  0.4.rc0 (4.30.12)
   - Shortcut keys feature
     - Press control+n to reset
     - Press command+n to reset (Mac OS X)
     - Press control+r for color red
     - Press command+r for color red (Mac OS X)
     - Press control+g for color green
     - Press command+g for color green (Mac OS X)
     - Press control+b for color blue
     - Press command+b for color blue (Mac OS X)
     
  0.3.rc0 (4.27.12)
   - Fixed Escape key quit bug
   - Commenting for code
  
  0.2.b5 (4.20.12)
   - Added copyright message
   
  0.2.b4 (4.18.12)
   - Added definition for bars under customer request
   
  0.2.a3 (4.17.12)
   - Added new Mac OS X icon (permanent)
   
  0.2.a2 (4.16.12)
   - Added new Mac OS X icon
   
  0.2.a1 (4.16.12)
   - Added Mac OS X icon
   
  0.2.a0 (4.14.12)
   - Changed the interface from text input to bar input
   - added color rectangle
   
  0.1.a1 (4.14.12)
   - Fixed reading number input bug
   
  0.1.a0 (4.14.12)
   - text input interface
   
  Release Candidate under test
  
  minhyukjang@gmail.com
  
  Thanks to the Control P5 Library
            http://wiki.processing.org/w/Export_Info_and_Tips
            http://processing.org/discourse/beta/num_1245332832.html
            http://wiki.processing.org/w/Multiple_key_presses
            http://www.sojamo.de/libraries/controlP5/examples/ControlP5color
            Picker/ControlP5colorPicker.pde
            
  
*/
 //Control P5 library

ControlP5 cp5;

ColorPicker cp;     //Control P5 is a color picker

boolean[] keys = new boolean[526];

public void setup(){
  size(700,700);    //700 x 700 pixels
  noStroke();
  cp5 = new ControlP5(this); //New color picker
  cp = cp5.addColorPicker("Color_Mixer") /*The color picker's name is 'Color_
                                           Mixer'
                                          */
          .setPosition(225,114) //position
          .setColorValue(color(0,0,0,255)) //initial color
          ;
}

public void draw(){
  background(0);    //Black background
  fill(255, 255, 255); //Text is white
  text("red", 220, 123); //Text...
  textAlign(RIGHT);
  text("green", 220, 134); 
  textAlign(RIGHT);
  text("blue", 220, 145); 
  textAlign(RIGHT);
  text("brighness", 220, 156); 
  textAlign(RIGHT);
  text("\u00a9 2012", 695, 671); 
  textAlign(RIGHT);
  text("Daniel Min Hyuk Jang", 695, 682); 
  textAlign(RIGHT);
  text("MangoLabs", 695, 695); 
  textAlign(RIGHT);
  fill(cp.getColorValue()); /*Rectangle color is the color from the color 
                              picker
                             */
  rect(175,175,350,350); //Rectangle
}

public boolean checkKey(int k){
  if(keys.length >= k){
    return keys[k];  
  }
  return false;
}

public void keyPressed(){  //If keys are pressed...
  if(key == ESC){   //Intercept the ESC key in the application
    key = 0;        //Don't quit even if ESC was pressed
  }
  keys[keyCode] = true; //Keys pressed are true
  if(checkKey(CONTROL) && checkKey(KeyEvent.VK_R)){ /*If keys are Control+R(ese
                                                      t)
                                                     */
    cp.setColorValue(color(0,0,0,255)); //Reset to initial color
  }
  if(checkKey(157) && checkKey(KeyEvent.VK_R)){ //If keys are Command+R(eset)
    cp.setColorValue(color(0,0,0,255)); //Reset to initial color
  }
}

public void keyReleased(){ //If keys are released...
  keys[keyCode] = false; //Keys pressed are false
}
  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#FFFFFF", "Color_Mixer" });
  }
}
